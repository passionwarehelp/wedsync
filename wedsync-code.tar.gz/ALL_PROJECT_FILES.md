# WedSync - Complete Project Code

## ✅ Git Strategy: COMMIT ALL TO MAIN BRANCH

All files are production-ready. Commit directly to main.

---

## 📁 ROOT LEVEL FILES

