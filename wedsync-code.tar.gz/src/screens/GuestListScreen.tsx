import React, { useState, useEffect, useRef } from "react";
import { View, Text, Pressable, ScrollView, TextInput, Share, Modal } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRoute, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";
import { RootStackParamList } from "../navigation/RootNavigator";
import useWeddingStore from "../state/weddingStore";
import { LinearGradient } from "expo-linear-gradient";
import { fetchRSVPsFromCloud } from "../api/rsvp-sync";
import QRCode from "react-native-qrcode-svg";
import { format } from "date-fns";

type NavigationProp = NativeStackNavigationProp<RootStackParamList>;
type GuestListRouteProp = RouteProp<RootStackParamList, "GuestList">;

export default function GuestListScreen() {
  const navigation = useNavigation<NavigationProp>();
  const route = useRoute<GuestListRouteProp>();
  const { weddingId } = route.params;
  const hasSynced = useRef(false);

  // Use individual selectors to avoid infinite loops
  const weddings = useWeddingStore((s) => s.weddings);
  const allGuests = useWeddingStore((s) => s.guests);
  const addGuest = useWeddingStore((s) => s.addGuest);
  const updateWedding = useWeddingStore((s) => s.updateWedding);

  const wedding = weddings.find((w) => w.id === weddingId);
  const guests = allGuests.filter((g) => g.weddingId === weddingId);

  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "attending" | "declined" | "pending">("all");
  const [showInviteModal, setShowInviteModal] = useState(false);

  // Auto-sync RSVPs from cloud on mount
  useEffect(() => {
    if (!wedding || hasSynced.current) return;

    const syncRSVPs = async () => {
      try {
        hasSynced.current = true;
        const cloudRSVPs = await fetchRSVPsFromCloud(wedding.qrCode);

        // Get existing guest names/emails to avoid duplicates
        const currentGuests = allGuests.filter((g) => g.weddingId === weddingId);
        const existingGuests = new Set(
          currentGuests.map((g) => `${g.name.toLowerCase()}-${g.email?.toLowerCase() || ""}`)
        );

        let newGuestsAdded = 0;
        let totalAttending = 0;

        for (const rsvp of cloudRSVPs) {
          const guestKey = `${rsvp.name.toLowerCase()}-${rsvp.email?.toLowerCase() || ""}`;

          if (existingGuests.has(guestKey)) {
            continue;
          }

          const guestId = `guest-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

          addGuest({
            id: guestId,
            weddingId: wedding.id,
            name: rsvp.name,
            email: rsvp.email || undefined,
            phone: rsvp.phone || undefined,
            rsvpStatus: rsvp.attending ? "attending" : "declined",
            plusOne: rsvp.plusOne,
            plusOneName: rsvp.plusOneName || undefined,
            mealType: rsvp.attending ? rsvp.mealType : undefined,
            dietaryRestrictions: rsvp.dietaryRestrictions || undefined,
            message: rsvp.message || undefined,
            category: "other",
            addedAt: rsvp.submittedAt || new Date().toISOString(),
          });

          newGuestsAdded++;
          if (rsvp.attending) {
            totalAttending += rsvp.plusOne ? 2 : 1;
          }

          existingGuests.add(guestKey);
        }

        if (newGuestsAdded > 0) {
          updateWedding(wedding.id, {
            guestCount: wedding.guestCount + newGuestsAdded,
            rsvpCount: wedding.rsvpCount + totalAttending,
          });
        }
      } catch (error) {
        // Silently fail - don't interrupt the user
        console.log("Auto-sync failed:", error);
      }
    };

    syncRSVPs();
  }, [wedding?.qrCode]);

  const filteredGuests = guests.filter((guest) => {
    const matchesSearch = guest.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === "all" || guest.rsvpStatus === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const stats = {
    total: guests.length,
    attending: guests.filter((g) => g.rsvpStatus === "attending").length,
    declined: guests.filter((g) => g.rsvpStatus === "declined").length,
    pending: guests.filter((g) => g.rsvpStatus === "pending").length,
    plusOnes: guests.filter((g) => g.rsvpStatus === "attending" && g.plusOne).length,
  };

  if (!wedding) {
    return (
      <SafeAreaView className="flex-1 bg-black">
        <View className="flex-1 items-center justify-center">
          <Text className="text-neutral-500">Wedding not found</Text>
        </View>
      </SafeAreaView>
    );
  }

  const rsvpUrl = `https://rsvp.mywedsync.com/${wedding.qrCode}?couple=${encodeURIComponent(wedding.coupleName)}`;

  const handleShare = async () => {
    try {
      const weddingDate = format(new Date(wedding.weddingDate), "MMMM d, yyyy");
      await Share.share({
        message: `You're invited to ${wedding.coupleName}'s wedding on ${weddingDate}!\n\nPlease RSVP here: ${rsvpUrl}`,
        title: "Wedding RSVP",
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleCopyLink = async () => {
    await Share.share({
      message: rsvpUrl,
      title: "RSVP Link",
    });
  };

  return (
    <View className="flex-1 bg-black">
      <LinearGradient
        colors={["#1F1F1F", "#000000"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ paddingTop: 60, paddingBottom: 20, paddingHorizontal: 20 }}
      >
        <Pressable onPress={() => navigation.goBack()} className="mb-4">
          <Ionicons name="arrow-back" size={24} color="#F5B800" />
        </Pressable>

        <View className="flex-row items-center justify-between mb-4">
          <Text className="text-[#F5B800] text-2xl font-bold">Guest List</Text>
          <View className="flex-row items-center">
            <Pressable
              onPress={() => setShowInviteModal(true)}
              className="bg-neutral-800 rounded-full px-4 h-11 flex-row items-center justify-center mr-3 border border-neutral-700"
            >
              <Ionicons name="mail-outline" size={18} color="#F5B800" />
              <Text className="text-[#F5B800] font-semibold ml-2">Invite</Text>
            </Pressable>
            <Pressable
              onPress={() => navigation.navigate("AddGuest", { weddingId })}
              className="bg-[#F5B800] rounded-full w-11 h-11 items-center justify-center shadow-md"
            >
              <Ionicons name="add" size={26} color="#000000" />
            </Pressable>
          </View>
        </View>

        {/* RSVP Summary Stats */}
        <View className="flex-row justify-between mb-4 bg-neutral-900/50 rounded-xl p-3 border border-neutral-800">
          <View className="items-center flex-1">
            <Text className="text-emerald-400 text-lg font-bold">{stats.attending}</Text>
            <Text className="text-neutral-500 text-xs">Attending</Text>
          </View>
          <View className="items-center flex-1">
            <Text className="text-red-400 text-lg font-bold">{stats.declined}</Text>
            <Text className="text-neutral-500 text-xs">Declined</Text>
          </View>
          <View className="items-center flex-1">
            <Text className="text-amber-400 text-lg font-bold">{stats.pending}</Text>
            <Text className="text-neutral-500 text-xs">Pending</Text>
          </View>
          <View className="items-center flex-1">
            <Text className="text-[#F5B800] text-lg font-bold">{stats.attending + stats.plusOnes}</Text>
            <Text className="text-neutral-500 text-xs">Total</Text>
          </View>
        </View>

        <View className="bg-neutral-900 rounded-2xl flex-row items-center px-4 py-3 mb-4 border border-neutral-800">
          <Ionicons name="search" size={18} color="#9CA3AF" />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="Search guests..."
            placeholderTextColor="#6B7280"
            className="flex-1 ml-3 text-base text-neutral-100"
          />
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <Pressable
            onPress={() => setFilterStatus("all")}
            className={`px-4 py-2 rounded-full mr-2 ${
              filterStatus === "all" ? "bg-[#F5B800]" : "bg-neutral-800"
            }`}
          >
            <Text className={`font-medium ${filterStatus === "all" ? "text-black" : "text-neutral-400"}`}>
              All ({stats.total})
            </Text>
          </Pressable>
          <Pressable
            onPress={() => setFilterStatus("attending")}
            className={`px-4 py-2 rounded-full mr-2 ${
              filterStatus === "attending" ? "bg-[#F5B800]" : "bg-neutral-800"
            }`}
          >
            <Text
              className={`font-medium ${filterStatus === "attending" ? "text-black" : "text-neutral-400"}`}
            >
              Attending ({stats.attending})
            </Text>
          </Pressable>
          <Pressable
            onPress={() => setFilterStatus("declined")}
            className={`px-4 py-2 rounded-full mr-2 ${
              filterStatus === "declined" ? "bg-[#F5B800]" : "bg-neutral-800"
            }`}
          >
            <Text
              className={`font-medium ${filterStatus === "declined" ? "text-black" : "text-neutral-400"}`}
            >
              Declined ({stats.declined})
            </Text>
          </Pressable>
          <Pressable
            onPress={() => setFilterStatus("pending")}
            className={`px-4 py-2 rounded-full ${filterStatus === "pending" ? "bg-[#F5B800]" : "bg-neutral-800"}`}
          >
            <Text className={`font-medium ${filterStatus === "pending" ? "text-black" : "text-neutral-400"}`}>
              Pending ({stats.pending})
            </Text>
          </Pressable>
        </ScrollView>
      </LinearGradient>

      <ScrollView className="flex-1 px-5 pt-5" showsVerticalScrollIndicator={false}>
        {filteredGuests.length === 0 ? (
          <View className="items-center justify-center py-20">
            <Ionicons name="people-outline" size={64} color="#404040" />
            <Text className="text-neutral-500 text-lg mt-4">
              {searchQuery ? "No guests found" : "No guests yet"}
            </Text>
            <Text className="text-neutral-600 text-sm mt-2 text-center px-8">
              {searchQuery ? "Try a different search" : "Tap Invite to send RSVP links or + to add guests manually"}
            </Text>
          </View>
        ) : (
          <View className="pb-6">
            {filteredGuests.map((guest, index) => (
              <Pressable
                key={guest.id}
                onPress={() => navigation.navigate("GuestDetail", { guestId: guest.id })}
                className={`bg-neutral-900 rounded-2xl p-4 border border-neutral-800 active:opacity-70${index < filteredGuests.length - 1 ? " mb-3" : ""}`}
              >
                <View className="flex-row items-start justify-between">
                  <View className="flex-1">
                    <Text className="text-neutral-100 text-lg font-semibold">{guest.name}</Text>
                    {guest.email && (
                      <Text className="text-neutral-400 text-sm mt-1">{guest.email}</Text>
                    )}
                    {guest.plusOne && guest.plusOneName && (
                      <View className="flex-row items-center mt-2">
                        <Ionicons name="person-add-outline" size={14} color="#F5B800" />
                        <Text className="text-neutral-400 text-sm ml-1">+1: {guest.plusOneName}</Text>
                      </View>
                    )}
                  </View>
                  <View
                    className={`px-3 py-1 rounded-full ${
                      guest.rsvpStatus === "attending"
                        ? "bg-emerald-900"
                        : guest.rsvpStatus === "declined"
                          ? "bg-red-900"
                          : "bg-amber-900"
                    }`}
                  >
                    <Text
                      className={`text-xs font-medium ${
                        guest.rsvpStatus === "attending"
                          ? "text-emerald-400"
                          : guest.rsvpStatus === "declined"
                            ? "text-red-400"
                            : "text-amber-400"
                      }`}
                    >
                      {guest.rsvpStatus === "attending"
                        ? "Attending"
                        : guest.rsvpStatus === "declined"
                          ? "Declined"
                          : "Pending"}
                    </Text>
                  </View>
                </View>

                <View className="flex-row items-center mt-3">
                  {guest.tableNumber && (
                    <View className={`flex-row items-center${guest.category ? " mr-4" : ""}`}>
                      <Ionicons name="restaurant-outline" size={16} color="#9CA3AF" />
                      <Text className="text-neutral-400 text-sm ml-1">Table {guest.tableNumber}</Text>
                    </View>
                  )}
                  {guest.category && (
                    <View className="flex-row items-center">
                      <Ionicons name="pricetag-outline" size={16} color="#9CA3AF" />
                      <Text className="text-neutral-400 text-sm ml-1 capitalize">
                        {guest.category.replace("-", " ")}
                      </Text>
                    </View>
                  )}
                </View>

                {/* Tap hint */}
                <View className="flex-row items-center justify-end mt-2">
                  <Text className="text-neutral-600 text-xs mr-1">View details</Text>
                  <Ionicons name="chevron-forward" size={14} color="#525252" />
                </View>
              </Pressable>
            ))}
          </View>
        )}
      </ScrollView>

      {/* Invite Modal */}
      <Modal visible={showInviteModal} transparent animationType="slide">
        <View className="flex-1 justify-end bg-black/70">
          <View className="bg-neutral-900 rounded-t-3xl p-6">
            <View className="flex-row items-center justify-between mb-6">
              <Text className="text-neutral-100 text-xl font-bold">Invite Guests</Text>
              <Pressable onPress={() => setShowInviteModal(false)}>
                <Ionicons name="close" size={24} color="#9CA3AF" />
              </Pressable>
            </View>

            {/* QR Code */}
            <View className="items-center mb-6">
              <View className="bg-white p-4 rounded-2xl">
                <QRCode value={rsvpUrl} size={160} backgroundColor="white" color="#000000" />
              </View>
              <Text className="text-neutral-400 text-sm mt-3 text-center">
                Guests can scan this QR code to RSVP
              </Text>
            </View>

            {/* Share Button */}
            <Pressable
              onPress={() => {
                setShowInviteModal(false);
                handleShare();
              }}
              className="bg-[#F5B800] rounded-xl py-4 flex-row items-center justify-center mb-3"
            >
              <Ionicons name="share-outline" size={22} color="#000000" />
              <Text className="text-black text-lg font-semibold ml-2">Share RSVP Link</Text>
            </Pressable>

            {/* Copy Link Button */}
            <Pressable
              onPress={() => {
                setShowInviteModal(false);
                handleCopyLink();
              }}
              className="bg-neutral-800 rounded-xl py-4 flex-row items-center justify-center border border-neutral-700"
            >
              <Ionicons name="copy-outline" size={22} color="#F5B800" />
              <Text className="text-neutral-100 text-lg font-semibold ml-2">Copy Link</Text>
            </Pressable>

            <Text className="text-neutral-600 text-xs text-center mt-4">
              Guests can RSVP without downloading the app
            </Text>
          </View>
        </View>
      </Modal>
    </View>
  );
}
